package com.example.datepickerandtimepicker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    int c_year,c_month,c_day;
    int c_hour,c_minute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Calendar calender=Calendar.getInstance();
        c_year=calender.get(Calendar.YEAR);
        c_month=calender.get(Calendar.MONTH);
        c_day=calender.get(Calendar.DAY_OF_MONTH);
    }

    public void datepicker(View view) {
        DatePickerDialog dp=new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2){
                Toast.makeText(MainActivity.this,
                        "Date:"+i+"-"+(i1+1)+"-"+i2,
                        Toast.LENGTH_SHORT).show();

            }
        },c_year,c_month,c_day);
        dp.show();
    }
    public void timepicker(View view) {
        TimePickerDialog tp= new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int i, int i1) {
                Toast.makeText(MainActivity.this,
                        "Time:"+i+":"+i1,
                        Toast.LENGTH_SHORT).show();
            }
        },c_hour,c_minute,true);
          tp.show();
        }


    public void alertdailog(View view) {
        AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Alert");
        builder.setMessage("Do you wnat close this app");
        builder.setIcon(R.drawable.baseline_batch_prediction_24);
        builder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        builder.setNegativeButton(":No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.show();
    }
}